#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int sys_fork(void)
{
  return fork();
}

int sys_exit(void)
{
  exit();
  return 0; // not reached
}

int sys_wait(void)
{
  return wait();
}

int sys_kill(void)
{
  int pid;

  if (argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int sys_getpid(void)
{
  return myproc()->pid;
}

int sys_sbrk(void)
{
  int addr;
  int n;

  if (argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if (growproc(n) < 0)
    return -1;
  return addr;
}

int sys_sleep(void)
{
  int n;
  uint ticks0;

  if (argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n)
  {
    if (myproc()->killed)
    {
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int sys_pgtPrint(void)
{

  pde_t *PgD = myproc()->pgdir;

  int Entry_No = 0;

  for (unsigned int i = 0; i < NPDENTRIES; i++)
  {
    pde_t *p = &PgD[i];

    if (*p & PTE_P && *p & PTE_U) // Checking  page directory is valid
    {
      pte_t *Pgt = (pte_t *)P2V((PTE_ADDR(*p))); // first 20 bits

      for (unsigned int j = 0; j < NPTENTRIES; j++)
      {
        pte_t *q = &Pgt[j];

        if (*q & PTE_P && *q & PTE_U) // Checking PTE is valid
        {
          Entry_No++;
          cprintf("Entry Number : %d pgdir Entry No : %d pgt Entry No : %d Virtual Address : %p Physical Address : %p\n", Entry_No,i,j, PGADDR(i, j, 0), *q);
        }
      }
    }
  }

  return 0;
}
