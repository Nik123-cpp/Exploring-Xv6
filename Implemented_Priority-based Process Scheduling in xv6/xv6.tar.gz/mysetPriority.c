#include "types.h"
#include "user.h"

int main()
{
    int pid = 0;
    
    pid = fork();
    if (pid < 0)
    {
        printf(1, "%d failed in fork! \n", getpid());
    }

    else if (pid > 0)
    {
        setPriority(4); // Giving more priority to parent
        printf(1, "Parent %d creating child %d\n", getpid(), pid);
        wait();
    }

    else
    {
        printf(1, "Child %d Created \n", getpid());
    }

    exit();
}